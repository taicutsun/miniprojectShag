const express = require("express");
app = express();
const path = require("path");
const cors = require("cors");

app.use(
  cors({
    origin: ["http://localhost:3001"],
    methods: ["GET", "POST"],
    credentials: true,
  })
);
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'hbs'); 


//data
const dishes=[
{
name:"burger",
price:10
},
{
name:"potato",
price:20
},
{
name:"pizza",
price:30
},
{
name:"sushi",
price:40
},
{
name:"shaurma",
price:50
},
];// menu
let basket=[];//for basket 
let balance=25;
let sumOfPrice=0;//summ of all products
//data


//get
app.get('/',(req,res)=>{//main menu
  res.render(path.join(__dirname,'public','views','index.hbs'),{balance});
});

app.get('/basket',(req,res)=>{//basket
  sumOfPrice=0;
for(let i=0;i<basket.length;i++){
   sumOfPrice+=basket[i].price; 

}
  res.render(path.join(__dirname,'public','views','basket.hbs'),{
    dishVisible:true,
    basket,
    sumOfPrice});
});

app.get("/buy",(req,res)=>{//result of transaction
  if(balance>=sumOfPrice){
    basket=[];sumOfPrice=0;balance-=sumOfPrice;//full reset main values for next cycle
    res.render(path.join(__dirname,'public','views','buy.hbs'),{success:true,});
  }
  else if(balance<=sumOfPrice){
    sumOfPrice=0;
    res.render(path.join(__dirname,'public','views','buy.hbs'),{success:false,});
  }
})

app.get('/topUp',(req,res)=>{//top up balance menu
  res.render(path.join(__dirname,'public','views','topUp.hbs'),{balance});
});
//get

//post
app.post('/basket',(req,res)=>{
const data = req.body;

let dish = dishes.find((d) => {
if(d.name === data.name){ return d.name } 
  });
  
basket.push(dish);//added new dish into basket

res.json(basket);
});

app.post('/delete',(req,res)=>{
let delObj = req.body;//name of deleted object

for(let i=0;i<basket.length;i++){
  if(basket[i].name ===delObj.name){
    sumOfPrice-=basket[i].price;
    basket.splice(i,1);
  }
}

console.log(basket);console.log(`sum=${sumOfPrice}`);
res.json(`deleted object ---${delObj.name}`);
});

app.post('/topUp',(req,res)=>{//increase balance by some value (from 'topUp' function)
let n = req.body;console.log(n)
balance+=n.increase;

res.json({balance})
});

//post

app.listen(3001);