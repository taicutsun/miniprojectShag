//helper for basket (deletePart)
const urlD = 'http://localhost:3001/delete';//url for delete

async function del(d,e){
  e.parentNode.parentNode.style.display = "none";//скрытее обьекта

let sendData={
  name:d
};

const response = await fetch(urlD, {
method: 'POST', 
body: JSON.stringify(sendData),
headers: {
'Content-Type': 'application/json;charset=utf-8'
}
});
try{
const json = await response.json();
console.log('Успех:', JSON.stringify(json));
} catch (error) {
console.error('Ошибка:', error);
  }
}
//helper for basket (deletePart)

//helper for top up balance

const urlT =  'http://localhost:3001/topUp';//url for /topUp

async function topUp(d){

let sendData={
  increase:d
};

const response = await fetch(urlT, {
method: 'POST', 
body: JSON.stringify(sendData),
headers: {
'Content-Type': 'application/json;charset=utf-8'
}
});
try{
const json = await response.json();
console.log('Успех:', JSON.stringify(json));
} catch (error) {
console.error('Ошибка:', error);
  }
}

//helper for top up balance

//helper for entering promocode
const urlP =  'http://localhost:3001/promo';//url for /promo

async function promo(d){

let sendData={
  promo:d
};

const response = await fetch(urlP, {
method: 'POST', 
body: JSON.stringify(sendData),
headers: {
'Content-Type': 'application/json;charset=utf-8'
}
});
try{
const json = await response.json();
console.log('Успех:', JSON.stringify(json));
} catch (error) {
console.error('Ошибка:', error);
  }
}
//helper for entering promocode